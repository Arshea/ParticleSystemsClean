#common globals
class BootStrap:
    PyClient = None
    